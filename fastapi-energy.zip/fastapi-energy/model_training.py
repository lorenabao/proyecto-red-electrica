import os
import pandas as pd
import numpy as np
import pickle
import psycopg2
import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy import text

import xgboost as xgb
from sklearn.metrics import mean_absolute_error, mean_squared_error
import json

from datetime import timedelta


def conexion_RDS():
    with open("../credentials/bbdd.json") as f:
        bbdd = json.load(f)

    host = bbdd["host"]
    database = bbdd["database"]
    user = bbdd["user"]
    password = bbdd["password"]

    engine = create_engine(f"postgresql+psycopg2://{user}:{password}@{host}/{database}")
    # Bloque de test - cierra automáticamente la conexión
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT 1")).all()
        df = pd.read_sql_table(table_name="demanda_electrica", con=conn)
        print(df.head())

    connection = engine.connect()
    df = pd.read_sql_table(table_name="demanda_electrica", con=connection)
    connection.close()
    engine.dispose()

    return df
def clean_df(df):
    df_clean=df.copy()
    #limpiamos dataframe de lo que no nos interesa
    df_clean["converted_datetime_utc_date"] = pd.to_datetime(df_clean["datetime_utc"], utc=True)
    df_clean = df_clean.drop(columns = ["datetime", "datetime_utc", "tz_time", "geo_id", "geo_name"])
    #introducimos 1 dias anterior 2 y 7
    df_clean["past_day"]=df_clean["value"].shift(1)
    df_clean["past_2day"]=df_clean["value"].shift(2)
    df_clean["past_7day"]=df_clean["value"].shift(7)
    #features especiales
    df_clean["day_week"] = df_clean["converted_datetime_utc_date"].dt.dayofweek    # 0=lunes, 6=domingo
    df_clean["day"] = df_clean["converted_datetime_utc_date"].dt.day
    df_clean["month"] = df_clean["converted_datetime_utc_date"].dt.month
    df_clean["year"] = df_clean["converted_datetime_utc_date"].dt.year
    #dias a futuro
    df_clean["nextday"]=df_clean["value"].shift(-1)
    df_clean["next2day"]=df_clean["value"].shift(-2)
    df_clean["next3day"]=df_clean["value"].shift(-3)

    return df_clean


def train_test(df):
    corte = df_clean["converted_datetime_utc_date"].max() - pd.Timedelta(days=60)

    test_df = df_clean[df_clean["converted_datetime_utc_date"] >= corte]
    train_df = df_clean[df_clean["converted_datetime_utc_date"] < corte]

    print(
        f"Train: \n Fecha min: {train_df["converted_datetime_utc_date"].min()} \n Fecha max: {train_df["converted_datetime_utc_date"].max()} \n Len: {len(train_df)}")
    print(
        f"Test: \n Fecha min: {test_df["converted_datetime_utc_date"].min()} \n Fecha max: {test_df["converted_datetime_utc_date"].max()} \n Len: {len(test_df)}")

    X_train = train_df[["value", "past_day", "past_2day", "past_7day", "day_week", "day", "month", "year"]]
    y_train = train_df["nextday"]
    y_train2 = train_df["next2day"]
    y_train3 = train_df["next3day"]
    X_test = test_df[["value", "past_day", "past_2day", "past_7day", "day_week", "day", "month", "year"]]
    y_test = test_df["nextday"]
    y_test2 = test_df["next2day"]
    y_test3 = test_df["next3day"]

    return X_train, X_test, y_train, y_train2, y_train3, y_test, y_test2, y_test3


def modelo(X_train, X_test, y_train, y_train2, y_train3, y_test, y_test2, y_test3):
    # para un dia
    model1 = xgb.XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.8
    )

    model1.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)

    # para 2 dias
    model2 = xgb.XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.8
    )

    model2.fit(X_train, y_train2, eval_set=[(X_test, y_test2)], verbose=False)

    # para 3 dias
    model3 = xgb.XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.8
    )

    model3.fit(X_train, y_train3, eval_set=[(X_test, y_test3)], verbose=False)

    with open("model_1.pkl", "wb") as file:
        pickle.dump(model1, file)
    with open("model_2.pkl", "wb") as file:
        pickle.dump(model2, file)
    with open("model_3.pkl", "wb") as file:
        pickle.dump(model3, file)

    return (model1, model2, model3)


def pred_dias(dias, prediccion, model1, model2, model3, X_test, y_test):
    if dias == 1:
        nextday = model1.predict(prediccion)[0]
        y_pred = model1.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred)
        return (nextday, mae)

    if dias == 2:
        next2days = model2.predict(prediccion)[0]
        y_pred2 = model2.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred2)
        return (next2days, mae)

    if dias == 3:
        next3days = model3.predict(prediccion)[0]
        y_pred3 = model3.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred3)
        return (next3days, mae)


if __name__ == "__main__":
    df = conexion_RDS()
    df_clean = clean_df(df)
    df_clean = df_clean.dropna(subset=["nextday", "next2day", "next3day"])
    X_train, X_test, y_train, y_train2, y_train3, y_test, y_test2, y_test3 = train_test(df_clean)
    model1, model2, model3 = modelo(X_train, X_test, y_train, y_train2, y_train3, y_test, y_test2, y_test3)

    print("Modelos entrenados y guardados como model_1.pkl, model_2.pkl, model_3.pkl")
