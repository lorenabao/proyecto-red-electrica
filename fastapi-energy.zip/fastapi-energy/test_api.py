import requests

BASE_URL = "http://127.0.0.1:8000"


def query_demanda(question, history=None):

    question_lower = question.lower()

    # Palabras clave para futuro
    future_keywords = ["mañana", "próximo", "siguiente", "forecast", "predecir"]

    # Palabras clave para pasado
    past_keywords = ["ayer", "pasado", "histórico", "demanda del", "qué fue"]

    if any(k in question_lower for k in future_keywords):
        # Usa /forecast
        days = 1
        payload = {"days": days, "history": history or [1000, 1020, 1015, 1030, 1025, 1040, 1035]}
        response = requests.post(f"{BASE_URL}/forecast", json=payload)
        print(f"Pregunta (futuro): {question}")
        print(response.status_code)
        print(response.json())
    elif any(k in question_lower for k in past_keywords):
        # Usa /ask
        payload = {"question": question}
        response = requests.post(f"{BASE_URL}/ask", json=payload)
        print(f"Pregunta (pasado): {question}")
        print(response.status_code)
        print(response.json())
    else:
        print(f"No se puede determinar si la pregunta es pasada o futura: {question}")


if __name__ == "__main__":
    # Pregunta futura
    query_demanda("¿Qué demanda crees que habrá mañana?")

    # Pregunta pasada
    query_demanda("¿Cuál fue la demanda del 23 de junio de 2016?")

