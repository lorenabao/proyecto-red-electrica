from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import numpy as np
import os
import pytz

from app.sql_service import text_to_SQL, consultar_BD
from app.model_loader import load_models, MODELS, MODEL_META

# Carga de los modelos
load_models()

app = FastAPI(title="FastAPI Demanda Electrica")

# Zona horaria Estocolmo (es la que tenemos en AWS)
TZ = pytz.timezone(os.getenv("TZ", "Europe/Stockholm"))


class ForecastRequest(BaseModel):
    days: int
    history: Optional[List[float]] = None


class ForecastPoint(BaseModel):
    date: str
    value: float


class ForecastResponse(BaseModel):
    days: int
    predictions: List[ForecastPoint]
    meta: Optional[dict] = None


class AskRequest(BaseModel):
    question: str


# Endpoints
@app.get("/")
def home():
    return {"message": "API de predicción de demanda eléctrica."}


@app.get("/models")
def models():
    # devuelve los modelos cargados
    resp = {}
    for d in (1, 2, 3):
        model_key = f"model_{d}"
        resp[d] = MODEL_META.get(model_key, {})
    return resp


@app.post("/forecast", response_model=ForecastResponse)
def forecast(req: ForecastRequest):
    days = req.days
    if days not in (1, 2, 3):
        raise HTTPException(status_code=400, detail="days must be 1, 2 or 3")

    # Obtener modelo correcto
    model_key = f"model_{days}"
    model = MODELS.get(model_key)
    meta = MODEL_META.get(model_key, {})

    # Si no hay modelo
    if model is None:
        if not req.history or len(req.history) == 0:
            raise HTTPException(
                status_code=503,
                detail=f"Modelo de {days}d no disponible y no se proporcionó 'history' para fallback."
            )
        buffer = list(req.history)
        preds = []
        last_date = datetime.now(TZ).date()
        for i in range(days):
            last_val = buffer[-1]
            next_val = float(last_val * 1.01)  # +1% simple
            next_date = (last_date + timedelta(days=i + 1)).isoformat()
            preds.append({"date": next_date, "value": round(next_val, 3)})
            buffer.append(next_val)
        return {"days": days, "predictions": preds, "meta": {"used_model": False, "note": "fallback dummy", **meta}}


    # Predecir con modelo real
    n_features = getattr(model, "n_features_in_", None)
    history = req.history or []

    if n_features is not None and len(history) < n_features:
        raise HTTPException(
            status_code=400,
            detail=f"El modelo requiere history con al menos {n_features} valores."
        )
    if len(history) == 0:
        raise HTTPException(
            status_code=400,
            detail="Proporciona 'history' (lista de floats) para que el modelo pueda predecir."
        )

    buffer = list(history)
    preds = []
    last_date = datetime.now(TZ).date()

    # Intento de predicción vectorizada
    X = np.array(buffer[-n_features:]).reshape(1, -1) if n_features is not None else np.array(buffer).reshape(1, -1)
    y = model.predict(X)

    try:
        arr = np.array(y)
        if arr.ndim == 2 and arr.shape[1] == days:
            for i in range(days):
                val = float(arr[0, i])
                preds.append({"date": (last_date + timedelta(days=i + 1)).isoformat(), "value": round(val, 3)})
            return {"days": days, "predictions": preds, "meta": {"used_model": True, **meta}}
    except Exception:
        pass

    # Si el modelo devuelve solo 1 valor, hacemos predicción recursiva
    buffer = list(history)
    for i in range(days):
        Xi = np.array(buffer[-n_features:]).reshape(1, -1) if n_features is not None else np.array(buffer).reshape(1,
                                                                                                                   -1)
        ypred = model.predict(Xi)
        yval = float(np.array(ypred).ravel()[0]) if hasattr(ypred, "__len__") else float(ypred)
        next_date = (last_date + timedelta(days=i + 1)).isoformat()
        preds.append({"date": next_date, "value": round(yval, 3)})
        buffer.append(yval)

    return {"days": days, "predictions": preds, "meta": {"used_model": True, **meta}}



# /ask usando sql_service.py
@app.post("/ask")
def ask(req: AskRequest):
    try:
        sql = text_to_SQL(req.question)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"No se pudo interpretar la pregunta: {e}")

    try:
        result = consultar_BD(sql)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error ejecutando la consulta SQL: {e}")

    return {"question": req.question, "answer": result}
