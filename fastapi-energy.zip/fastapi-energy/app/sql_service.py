import psycopg2
from transformers import pipeline
from googletrans import Translator


# Función que transforma texto a SQL
def text_to_SQL(texto: str) -> str:
    from transformers import pipeline
    from googletrans import Translator

    translator = Translator()

    Query = translator.translate(texto, src='es', dest='en').text

    text_to_SQL = pipeline("text-generation", model="Ellbendls/Qwen-2.5-3b-Text_to_SQL")
    messages = [
        {"role": "user",
         "content": ("You are an assistant that generates **only valid PostgreSQL queries**. "
                     "The only table is demanda_electrica with columns: "
                     "datetime (TEXT, format 'YYYY-MM-DD HH:MM:SS'), value (NUMERIC), geo_location (TEXT). "
                     "Rules:\n"
                     "- Write only the SQL query, nothing else.\n"
                     "- Output only one SQL query ending with a semicolon (;).\n"
                     "- Do not use MySQL/SQLite functions (YEAR, MONTH, DAY, strftime, DATE()).\n"
                     "- If a specific day is mentioned, use a range: "
                     "datetime >= 'YYYY-MM-DD 00:00:00' AND datetime < 'YYYY-MM-DD 23:59:59'.\n"
                     "- Do not use unsupported types or syntax.\n"
                     "- Only SELECT queries (no INSERT/UPDATE/DELETE).\n"
                     "- If you use aggregates (MAX, MIN, AVG, SUM, COUNT), "
                     "do not select raw columns unless using GROUP BY.\n\n"
                     f"Task: {Query}")
         }
    ]
    consultaSQL = text_to_SQL(messages)
    texto_generado = consultaSQL[0]['generated_text'][1]['content']
    sql = texto_generado.split("SQL Query:")[-1].strip()

    return sql


# Función que ejecuta la consulta en la base de datos
def consultar_BD(consulta: str):
    try:
        conn = psycopg2.connect(
            dbname='ree',
            user='postgres',
            password='postgres',
            host='rds-ree.cf4666uiqche.eu-north-1.rds.amazonaws.com',
            port=5432
        )
        conn.autocommit = True
        cur = conn.cursor()
        cur.execute(consulta)  # Ejecutamos la query
        column_names = [desc[0] for desc in cur.description]
        data = cur.fetchall()
        cur.close()
        conn.close()
        return data
    except Exception as e:
        print(f"❌ Error de conexión/consulta: {e}")
        return None
