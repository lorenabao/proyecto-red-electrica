import psycopg2
import os

DB_HOST = os.getenv("DB_HOST", "13.62.85.98")
DB_NAME = os.getenv("DB_NAME", "ree")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASS = os.getenv("DB_PASS", "postgres")

def get_connection():
    return psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )

def exec_scalar_query(query: str):
    #devuelve el valor en sql
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(query)
        result = cur.fetchone()
        return result[0] if result else None
    finally:
        cur.close()
        conn.close()
