import psycopg2
import os
from datetime import datetime

DB_HOST = os.getenv("DB_HOST", "13.62.85.98")
DB_NAME = os.getenv("DB_NAME", "ree")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASS = os.getenv("DB_PASS", "postgres")

def get_connection():
    return psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )

def get_last_n_values(n: int):
    """
    Devuelve los últimos n valores de demanda_electrica ordenados por fecha ascendente
    """
    query = f"""
        SELECT value
        FROM demanda_electrica
        ORDER BY datetime DESC
        LIMIT {n};
    """
    try:
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query)
                rows = cur.fetchall()
                # rows está en orden DESC, los revertimos para que queden ascendente
                return [r[0] for r in reversed(rows)]
    except Exception as e:
        print(f"Error consultando la BD: {e}")
        return []
