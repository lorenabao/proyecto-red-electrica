from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import numpy as np
import os
import pytz

from app.sql_service import text_to_SQL, consultar_BD
from app.model_loader import load_models, MODELS, MODEL_META
from app.db import get_last_n_values


# Carga de los modelos
load_models()

app = FastAPI(title="FastAPI Demanda Electrica")


try:
    last_vals = get_last_n_values(5)
    if last_vals:
        print(f"[DB TEST] Conexión exitosa, últimos valores: {last_vals}")
    else:
        print("[DB TEST] Conexión OK, pero no hay valores en la BD")
except Exception as e:
    print(f"[DB TEST] Error conectando a la BD: {e}")
# Zona horaria Estocolmo (es la que tenemos en AWS)
TZ = pytz.timezone(os.getenv("TZ", "Europe/Stockholm"))


class ForecastRequest(BaseModel):
    days: int
    history: Optional[List[float]] = None


class ForecastPoint(BaseModel):
    date: str
    value: float


class ForecastResponse(BaseModel):
    days: int
    predictions: List[ForecastPoint]
    meta: Optional[dict] = None


class AskRequest(BaseModel):
    question: str


# Endpoints
@app.get("/")
def home():
    return {"message": "API de predicción de demanda eléctrica."}


@app.get("/models")
def models():
    # devuelve los modelos cargados
    resp = {}
    for d in (1, 2, 3):
        model_key = f"model_{d}"
        resp[d] = MODEL_META.get(model_key, {})
    return resp




@app.post("/forecast", response_model=ForecastResponse)
def forecast(req: ForecastRequest):
    days = req.days
    if days not in (1, 2, 3):
        raise HTTPException(status_code=400, detail="days must be 1, 2 or 3")

    model_key = f"model_{days}"
    model = MODELS.get(model_key)
    meta = MODEL_META.get(model_key, {})

    if model is None:
        # fallback dummy
        buffer = list(req.history or [])
        if not buffer:
            # intentar obtener últimos valores de la BD
            buffer = get_last_n_values(n=7)  # ajustar según lo que necesite tu modelo
            if not buffer:
                raise HTTPException(
                    status_code=503,
                    detail="No hay modelo ni valores históricos en BD para fallback."
                )
        preds = []
        last_date = datetime.now(TZ).date()
        for i in range(days):
            last_val = buffer[-1]
            next_val = float(last_val * 1.01)  # +1% simple
            next_date = (last_date + timedelta(days=i + 1)).isoformat()
            preds.append({"date": next_date, "value": round(next_val, 3)})
            buffer.append(next_val)
        return {"days": days, "predictions": preds, "meta": {"used_model": False, "note": "fallback dummy", **meta}}

    # Obtener el número de features que espera el modelo
    n_features = getattr(model, "n_features_in_", None)
    history = req.history or []

    # si no hay history, tomar de la BD
    if len(history) < n_features:
        needed = n_features - len(history)
        history_from_db = get_last_n_values(n=needed)
        history = history_from_db + history  # concatenar DB + history proporcionado

    if len(history) < n_features:
        raise HTTPException(
            status_code=400,
            detail=f"No hay suficientes valores históricos para alimentar el modelo (necesarios: {n_features})"
        )

    # Predicción real
    buffer = list(history)
    preds = []
    last_date = datetime.now(TZ).date()
    X = np.array(buffer[-n_features:]).reshape(1, -1)
    y = model.predict(X)

    try:
        arr = np.array(y)
        if arr.ndim == 2 and arr.shape[1] == days:
            for i in range(days):
                val = float(arr[0, i])
                preds.append({"date": (last_date + timedelta(days=i + 1)).isoformat(), "value": round(val, 3)})
            return {"days": days, "predictions": preds, "meta": {"used_model": True, **meta}}
    except Exception:
        pass

    # predicción recursiva si el modelo devuelve solo 1 valor
    buffer = list(history)
    for i in range(days):
        Xi = np.array(buffer[-n_features:]).reshape(1, -1)
        ypred = model.predict(Xi)
        yval = float(np.array(ypred).ravel()[0])
        next_date = (last_date + timedelta(days=i + 1)).isoformat()
        preds.append({"date": next_date, "value": round(yval, 3)})
        buffer.append(yval)

    return {"days": days, "predictions": preds, "meta": {"used_model": True, **meta}}




# /ask usando sql_service.py
@app.get("/ask/")
async def generar_consulta(ask: str):
    try:
        sql = text_to_SQL(ask)
        resultado = consultar_BD(sql)
        return {"sql": sql, "resultado": resultado}
    except Exception as e:
        return {"detail": f"No se pudo interpretar la pregunta: {e}"}

