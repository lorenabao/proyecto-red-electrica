import os
import joblib

MODEL_DIR = os.getenv("MODEL_DIR", "models")

MODELS = {}
MODEL_META = {}

def load_models():
    #carga los 3 modelos
    mapping = {
        "model1": "model_1.pkl",
        "model2": "model_2.pkl",
        "model3": "model_3.pkl"
    }

    for key, filename in mapping.items():
        fname = os.path.join(MODEL_DIR, filename)
        if os.path.exists(fname):
            try:
                m = joblib.load(fname)
                MODELS[key] = m
                MODEL_META[key] = {
                    "path": fname,
                    "status": "available"
                }
                print(f"[model_loader] Cargado {key} desde {fname}")
            except Exception as e:
                MODELS[key] = None
                MODEL_META[key] = {
                    "path": fname,
                    "status": "error",
                    "detail": str(e)
                }
        else:
            MODELS[key] = None
            MODEL_META[key] = {
                "path": fname,
                "status": "not found"
            }
