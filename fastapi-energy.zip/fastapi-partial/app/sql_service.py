import os,requests, io, json
from io import StringIO
from datetime import datetime, timedelta, timezone
import pandas as pd
import psycopg2
from huggingface_hub import InferenceClient
from googletrans import Translator

#hago un acceso por inference cliente par ano consumir toda la memoria de EC2
token_acceso=os.getenv("token_acceso","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")
#modelo de hugging face con compatibilidad con inference client
clienteSQL = InferenceClient(model="defog/llama-3-sqlcoder-8b",token=token_acceso)
translator = Translator()
def text_to_SQL(texto):
    #con esta funcion uso  el modelo de hugging face para pasarle primero
    #traduccion al ingles y luego que saque un query
    Query=translator.translate(texto, src='es', dest='en').text
    
    prompt = (
        
         "You are an assistant that generates **only valid PostgreSQL queries**. "
        "The only table is demanda_electrica with columns: "
        "datetime (TIMESTAMP, format 'YYYY-MM-DD HH:MM:SS'), value (NUMERIC)"
        "Rules:\n"
        "- Write only the SQL query, nothing else.\n"
        "- Output only one SQL query ending with a semicolon (;).\n"
        "- Do not use MySQL/SQLite functions (YEAR, MONTH, DAY, strftime, DATE()).\n"
        "- If a specific day is mentioned, use a range: "
        "datetime >= 'YYYY-MM-DD 00:00:00' AND datetime < 'YYYY-MM-DD 23:59:59'.\n"
        "- Do not use unsupported types or syntax.\n"
        "- Only SELECT queries (no INSERT/UPDATE/DELETE).\n"
        "- If you use aggregates (MAX, MIN, AVG, SUM, COUNT), "
        "do not select raw columns unless using GROUP BY.\n\n"
        f"Task: {Query}"
    )#para la query utilizo un prompt para darle una serie de requisitos y restricciones 
    #para que asi solo saque sentencias de SQL
    consultaSQL=clienteSQL.chat_completion(messages=[{"role": "user", "content":prompt}])
    texto_generado = consultaSQL['choices'][0]['message']['content'].strip()
    sql=texto_generado
    return sql

def consultar_BD(consulta):
    
    try:
        
        with open("credentials/bbdd.json") as f:
            bbdd = json.load(f)

        conn = psycopg2.connect(
    
            host=bbdd["host"],
            database=bbdd["database"],
            user=bbdd["user"],
            password=bbdd["password"]
        )
        conn.autocommit = True
        cur = conn.cursor()
        cur.execute(consulta) # Ejecutamos la query
        column_names = [desc[0] for desc in cur.description] # Nombre de las columnas de la tabla
        
        # Guardamos los datos de la tabla
        data = cur.fetchall()
        
        cur.close()
        conn.close()

        return data
    except Exception as e:
        print(f"❌ Error de conexión/creación: {e}")


