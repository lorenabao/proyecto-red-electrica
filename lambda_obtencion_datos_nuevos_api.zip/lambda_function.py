import boto3, json, requests
from datetime import datetime, timedelta

s3 = boto3.client("s3")
BUCKET_NAME = "hab-ree-data-json"
TOKEN = "7420a3ca94b624b807706ac3f0f84e75ca65e5ea233d50a5a620da00662ea881"

def lambda_handler(event, context):
    headers = {
        "Accept": "application/json;",
        "Content-Type": "application/json",
        "x-api-key": TOKEN
    }
    
    # Fechas últimas 24h
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=1)

    params = {
        "start_date": start_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "end_date": end_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "time_trunc": "day"
    }

    url = "https://api.esios.ree.es/indicators/1293"
    response = requests.get(url, params=params, headers=headers)
    if response.status_code != 200:
        return {"statusCode": response.status_code, "body": response.text}

    data = response.json()

    # Guardar en S3 usando particionado por fecha
    filename = f"nuevos_datos/{start_date.year}/{start_date.month:02}/{start_date.day:02}/data.json"
    s3.put_object(
        Bucket=BUCKET_NAME,
        Key=filename,
        Body=json.dumps(data, ensure_ascii=False).encode("utf-8"),
        ContentType="application/json"
    )

    return {"statusCode": 200, "body": f"Datos guardados en {filename}"}
