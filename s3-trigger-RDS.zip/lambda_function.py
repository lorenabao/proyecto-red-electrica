import json
import urllib.parse
import boto3
import os
import psycopg2


s3 = boto3.client('s3')

dbname=os.environ['DB']
user=os.environ['USER'],
password=os.environ['PASSWORD'],
host=os.environ['HOST'],
port=int(os.environ.get('PORT',5432))


def lambda_handler(event, context):
    
    #sacamos primero la informacion del evento
    event_s3=event['Records'][0]['s3']
    bucket =event_s3['bucket']['name']
    key =event_s3['object']['key']
    
    print(f"archivo subido al bucket de s3 {bucket} con nombre {key}")

#ahora de ese evento sacamos el body que es el contenido
#que me interesa para actualizar la base de datos
    item=s3.get_object(Bucket=bucket, Key=key)
    body=item['Body'].read().decode('utf-8')
    data=json.loads(body)
    print(data)

#me conecto con las variables de entorno
    conn = psycopg2.connect(
            dbname=dbname,
            user=user,
            password=password,
            host=host,
            port=port
        )
        #creo el cursor
    cur = conn.cursor()
    #ahora insertamos los datos con el formato de la tabla
    sql = """INSERT INTO demanda electrica (value, datetime, datetime_utc,
    tz_time,geo_id,geo_name) VALUES (%s, %s, %s, %s, %s, %s)""" 
    cur.execute(sql, (data['value'], data['datetime'], data['datetime_utc'],
    data['tz_time'],data['geo_id'],data['geo_name']))

    conn.commit()
    cur.close()
    conn.close()


    return{
        'statusCode':200,
        'body':json.dumps(data)
    }
